# Note
* I copy these files from other's share, for convenience to more people who annoyed by the WARN when configure spark on windows_X64.
* These are winutils.exe and hadoop lib for spark's running, it is based on hadoop2.7.3 and compiled under 64 bit Windows OS.
* Please copy the bin directory to your HADOOP_HOME directory, it will work!